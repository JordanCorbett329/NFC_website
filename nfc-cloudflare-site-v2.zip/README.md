Deploy to Cloudflare Pages with Framework preset: None, Build command blank/exit 0, Output dir: / (or public if you place files there).
